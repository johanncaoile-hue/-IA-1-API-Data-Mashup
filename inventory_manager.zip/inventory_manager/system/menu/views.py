from django.shortcuts import render
import requests

def base(request):
    query = request.GET.get('q', '')
    meals = []
    error_meal = None

    if query:
        try:
            meal_url = f'https://www.themealdb.com/api/json/v1/1/search.php?s={query}'
            response = requests.get(meal_url, timeout=5)
            data = response.json()
            meals = data.get('meals') or []  
        except Exception as e:
            error_meal = f"Error fetching meals: {str(e)}"

        if meals: #makes sure that not empty
            for meal in meals:
                name = meal.get('strMeal', '')
                if name:
                    try:
                        nutrition_url = f'https://api.nal.usda.gov/fdc/v1/foods/search?api_key=DEMO_KEY&query={name}'
                        nutrition_response = requests.get(nutrition_url, timeout=5)
                        meal['nutrition'] = nutrition_response.json().get('foods', []) or []
                    except:
                        meal['nutrition'] = []

    context = {
        'query': query,
        'meals': meals,
        'error_meal': error_meal,
    }
    return render(request, 'menu/base.html', context)